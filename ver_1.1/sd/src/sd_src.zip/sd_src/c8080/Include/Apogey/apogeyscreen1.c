#include <apogey/screen_constrcutor.h>

void apogeyScreen1() {
  APOGEY_SCREEN_STD(0xE1D0, 30, 25, 3, 0x77, 78, 0, 0, 0);
}

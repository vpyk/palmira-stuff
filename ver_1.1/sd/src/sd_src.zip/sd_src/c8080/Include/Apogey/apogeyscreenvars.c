#include <apogey/video.h>

uchar* apogeyVideoMem = (uchar*)(0xE1D0 + 78*3 + 8);
uchar  apogeyVideoBpl = 78;
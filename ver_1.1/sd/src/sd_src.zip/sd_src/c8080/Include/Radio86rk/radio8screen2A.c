#include <radio86rk/screen_constrcutor.h>

void radio86rkScreen2a() {
  RADIO86RK_SCREEN_ECONOMY(0x76D0, 37, 31, 3, 0x77, 75, 1, 0, 0);
}

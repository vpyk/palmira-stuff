void i2s(char* buf, uint v, uint n, uchar spc) @ "n/i2s.c";
void i2s32(char* buf, ulong* val, uint n, uchar spc) @ "n/i2s32.c";


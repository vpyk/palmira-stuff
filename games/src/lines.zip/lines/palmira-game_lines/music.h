extern uint  musicFreq[1];
extern uchar music[1];

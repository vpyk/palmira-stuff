extern uchar newBallSprite[16];
extern uchar ballSprite[16];
extern uchar killBallSprite[16];
extern uchar ballCursorSprite[16];
extern uchar emptySprite[16];
extern uchar cursorSprite[16];
extern uchar ballSprite1[16];

extern uchar sprite_stepUp[16];
extern uchar sprite_stepDown[16];
extern uchar sprite_stepLeft[16];
extern uchar sprite_stepRight[16];

extern uchar gameScreen[1];
extern uchar selAnimation1[16];
extern uchar selAnimation2[16];
extern uchar selCursorAnimation1[16];
extern uchar selCursorAnimation2[16];

extern uchar startScreen[1];
extern uchar leftSprite[1];
extern uchar rightSprite[1];	
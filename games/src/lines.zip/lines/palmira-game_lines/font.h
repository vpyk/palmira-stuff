extern uchar font[16];
extern uchar font2[16];
extern uchar fontSpace[16];
extern uchar fontEng[16];               
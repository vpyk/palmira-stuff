//#ifndef __MEM_H
//#define __MEM_H

uchar rand() @ "rand.c";

extern uint op_div16_mod;

//#endif
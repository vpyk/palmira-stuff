#include <apogey/screen_constrcutor.h>

void apogeyScreen3c() {
  APOGEY_SCREEN_ECONOMY_EXT(64, 51, 7, 0x33, 94, 0, 1, 1);
}

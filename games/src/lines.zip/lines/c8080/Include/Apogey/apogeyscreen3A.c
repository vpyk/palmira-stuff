#include <apogey/screen_constrcutor.h>

void apogeyScreen3a() {
  APOGEY_SCREEN_ECONOMY_EXT(64, 51, 7, 0x33, 75, 1, 0, 1);
}

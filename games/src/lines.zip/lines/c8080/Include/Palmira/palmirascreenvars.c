#include <palmira/video.h>

uchar* palmiraVideoMem = (uchar*)(0xB6D0 + 78*3 + 8);
uchar  palmiraVideoBpl = 78;
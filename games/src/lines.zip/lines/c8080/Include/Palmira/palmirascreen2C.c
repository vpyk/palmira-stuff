#include <palmira/screen_constrcutor.h>

void palmiraScreen2c() {
  PALMIRA_SCREEN_ECONOMY_EXT(37, 31, 3, 0x77, 94, 0, 1, 0);
}

#define SET_SOUND(CH, FREQ) { ((uchar*)0xCC00)[CH] = (uchar)(FREQ); ((uchar*)0xCC00)[CH] = (FREQ)>>8; }

#define MUTE_SOUND(CH) { *(uchar*)0xCC03 = ((CH)==0 ? 0x3E : ((CH)==1 ? 0x7E : 0xBE)); }

#include <palmira/video.h>
                             
uchar* charAddr(uchar x, uchar y) {
  return palmiraVideoMem + y * palmiraVideoBpl + x;
}

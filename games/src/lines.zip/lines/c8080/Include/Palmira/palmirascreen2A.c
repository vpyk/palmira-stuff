#include <palmira/screen_constrcutor.h>

void palmiraScreen2a() {
  PALMIRA_SCREEN_ECONOMY(0xB6D0, 37, 31, 3, 0x77, 75, 1, 0, 0);
}

#include <palmira/screen_constrcutor.h>

void palmiraScreen0() {
  PALMIRA_SCREEN_STD(0xB6D0, 30, 25, 3, 0x99, 78, 0, 0, 0);
}

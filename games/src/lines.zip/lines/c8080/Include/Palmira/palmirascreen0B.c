#include <palmira/screen_constrcutor.h>

void palmiraScreen0b() {
  PALMIRA_SCREEN_STD(0xB6D0, 30, 25, 3, 0x99, 78, 1, 1, 0);
}

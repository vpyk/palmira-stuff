#include <radio86rk/screen_constrcutor.h>

void radio86rkScreen2b() {
  RADIO86RK_SCREEN_ECONOMY_EXT(37, 31, 3, 0x77, 78, 1, 1, 0);
}

#include <radio86rk/screen_constrcutor.h>

void radio86rkScreen0() {
  RADIO86RK_SCREEN_STD(0x76D0, 30, 25, 3, 0x99, 78, 0, 0, 0);
}

#include <radio86rk/screen_constrcutor.h>

void radio86rkScreen2c() {
  RADIO86RK_SCREEN_ECONOMY_EXT(37, 31, 3, 0x77, 94, 0, 1, 0);
}

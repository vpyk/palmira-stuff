from PIL import Image

outut_file = 'tiles.asm'

tile_names = (
  'None',
  'Grass',
  'Stone',
  'Almas',
  'StopMan',
  'Wall',
  'Mina',
  'Babo',
  'LeftMan',
  'LeftMan1',
  'RightMan',
  'RightMan1',
  'UpMan',
  'UpMan1',
  'DownMan',
  'DownMan1',
  'Mina1',
  'Babo1'
)

char_gen = []
tiles = []

for tile_name in tile_names:
    file_name = tile_name + '.png'

    img = Image.open(file_name)
    img = img.convert('1')
    pixels = img.load()

    tile = []
    for cy in range(2):
        for cx in range(4):
            char = bytearray()
            for y in range(cy * 12, cy * 12 + 12):
                bt = 0
                for x in range(cx * 8, cx * 8 + 8):
                    bt <<= 1
                    if pixels[x,y] == 0:
                        bt |= 1
                char.append(bt)
            if not char in char_gen:
                char_gen.append(char)
            tile.append(char_gen.index(char))
    tiles.append((tile_name, tile))

with open(outut_file, 'w') as f:

    print(f'char_gen_len\t.equ {len(char_gen)}\n', file=f)
    print('char_gen:', file=f)
    for char in char_gen:
        print('\t.db',','.join([f'0{val:02X}h' for val in char]), file=f)

    print(file=f)

    for name, tile in tiles:
        print('Tile_'+name+':', file=f)
        print('\t.db',','.join([f'0{val:02X}h' for val in tile]), file=f)
        print(file=f)

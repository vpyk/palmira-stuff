# Bolder-Dash-PK8000
My port of the game "Bolder Dash" for the Soviet computer ПК8000 (PK8000).

This game called "Bolder Dash" was originally developed by A.V.Melentiev
for the Soviet computer "Elektronika BK-0010". Wladimir Mutel, inspired
by the game, performed its  manual disassembly and porting to the Soviet
computer "Poisk-1" (IBM XT clone).
Oleg N. Cher ported Mutel's game to the ZX Spectrum.
The game was adapted for the PK8000 by Andrey Hlus. All levels for the game
are provided by Alex Kotorov.

Programming language: PL/M-80. 
The build requires the PL/M-80 Tools: https://github.com/MrDemonid/PL-M-80-Tools
